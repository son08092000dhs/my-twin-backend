import 'dotenv/config';

export const config = {
  port: Number(process.env.PORT || 3000),
  nodeEnv: process.env.NODE_ENV || 'development',
  frontendOrigin: process.env.FRONTEND_ORIGIN || '*',
  jwtSecret: process.env.JWT_SECRET || '',
  openAiApiKey: process.env.OPENAI_API_KEY || '',
  openAiModel: process.env.OPENAI_MODEL || 'gpt-4o-mini',
  googleClientId: process.env.GOOGLE_CLIENT_ID || '',
  databaseFile: process.env.DATABASE_FILE || './data/my-twin.sqlite'
};

export function validateConfig() {
  if (config.jwtSecret.length < 32) {
    throw new Error('JWT_SECRET must be at least 32 characters. Set it in .env.');
  }
}
