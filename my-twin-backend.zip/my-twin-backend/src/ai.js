import OpenAI from 'openai';
import { config } from './config.js';

export async function generateTwinReply({ profile, history, message }) {
  if (!config.openAiApiKey) {
    throw Object.assign(new Error('AI chưa được kết nối. Máy chủ cần cấu hình OPENAI_API_KEY.'), { status: 503 });
  }
  const client = new OpenAI({ apiKey: config.openAiApiKey });
  const system = [
    'Bạn là MY TWIN, trợ lý AI cá nhân của chủ tài khoản.',
    'Hãy hỗ trợ hữu ích, trung thực; không khẳng định bạn là con người hay bản sao hoàn hảo.',
    `Tên hiển thị: ${profile.display_name || 'chưa cung cấp'}.`,
    `Giới thiệu: ${profile.bio || 'chưa cung cấp'}.`,
    `Phong cách giao tiếp mong muốn: ${profile.tone || 'rõ ràng, thân thiện'}.`,
    `Sở thích: ${profile.interests || 'chưa cung cấp'}.`,
    'Chỉ sử dụng thông tin hồ sơ được cung cấp; không bịa ký ức hay sự kiện cá nhân.'
  ].join('\n');
  const messages = [
    { role: 'system', content: system },
    ...history.slice(-12).map(m => ({ role: m.role, content: m.content })),
    { role: 'user', content: message }
  ];
  const response = await client.chat.completions.create({
    model: config.openAiModel,
    messages,
    temperature: 0.7,
    max_tokens: 700
  });
  return response.choices[0]?.message?.content?.trim() || 'Mình chưa tạo được câu trả lời. Bạn thử lại nhé.';
}
