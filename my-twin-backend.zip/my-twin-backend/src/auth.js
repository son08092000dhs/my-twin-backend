import crypto from 'node:crypto';
import jwt from 'jsonwebtoken';
import { OAuth2Client } from 'google-auth-library';
import { db } from './db.js';
import { config } from './config.js';

const googleClient = new OAuth2Client(config.googleClientId);

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, expected] = stored.split(':');
  const actual = crypto.scryptSync(password, salt, 64);
  const expectedBuf = Buffer.from(expected, 'hex');
  return actual.length === expectedBuf.length && crypto.timingSafeEqual(actual, expectedBuf);
}
function issueToken(user) {
  return jwt.sign({ sub: user.id, email: user.email }, config.jwtSecret, { expiresIn: '7d' });
}
export function createEmailAccount({ email, password }) {
  const normalized = String(email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)) throw Object.assign(new Error('Email không hợp lệ.'), { status: 400 });
  if (typeof password !== 'string' || password.length < 10) throw Object.assign(new Error('Mật khẩu cần ít nhất 10 ký tự.'), { status: 400 });
  const id = crypto.randomUUID();
  try {
    db.prepare('INSERT INTO users(id,email,password_hash) VALUES(?,?,?)').run(id, normalized, hashPassword(password));
    db.prepare('INSERT INTO profiles(user_id) VALUES(?)').run(id);
  } catch (e) {
    if (String(e.code).includes('CONSTRAINT')) throw Object.assign(new Error('Email này đã được đăng ký.'), { status: 409 });
    throw e;
  }
  const user = { id, email: normalized };
  return { token: issueToken(user), user };
}
export function loginWithPassword({ email, password }) {
  const normalized = String(email || '').trim().toLowerCase();
  const user = db.prepare('SELECT id,email,password_hash FROM users WHERE email=?').get(normalized);
  if (!user || !verifyPassword(String(password || ''), user.password_hash)) {
    throw Object.assign(new Error('Email hoặc mật khẩu không đúng.'), { status: 401 });
  }
  return { token: issueToken(user), user: { id: user.id, email: user.email } };
}
export async function loginWithGoogle(idToken) {
  if (!config.googleClientId) throw Object.assign(new Error('Google Sign-In chưa được cấu hình trên máy chủ.'), { status: 503 });
  const ticket = await googleClient.verifyIdToken({ idToken, audience: config.googleClientId });
  const payload = ticket.getPayload();
  if (!payload?.sub || !payload.email || !payload.email_verified) throw Object.assign(new Error('Không xác minh được tài khoản Google.'), { status: 401 });
  let user = db.prepare('SELECT id,email FROM users WHERE google_sub=? OR email=?').get(payload.sub, payload.email.toLowerCase());
  if (!user) {
    const id = crypto.randomUUID();
    db.prepare('INSERT INTO users(id,email,google_sub) VALUES(?,?,?)').run(id, payload.email.toLowerCase(), payload.sub);
    db.prepare('INSERT INTO profiles(user_id,display_name) VALUES(?,?)').run(id, payload.name || '');
    user = { id, email: payload.email.toLowerCase() };
  } else {
    db.prepare('UPDATE users SET google_sub=COALESCE(google_sub,?) WHERE id=?').run(payload.sub, user.id);
  }
  return { token: issueToken(user), user };
}
export function requireAuth(req, res, next) {
  const value = req.headers.authorization || '';
  const token = value.startsWith('Bearer ') ? value.slice(7) : '';
  try {
    const payload = jwt.verify(token, config.jwtSecret);
    req.user = { id: payload.sub, email: payload.email };
    next();
  } catch {
    res.status(401).json({ error: 'Vui lòng đăng nhập lại.' });
  }
}
