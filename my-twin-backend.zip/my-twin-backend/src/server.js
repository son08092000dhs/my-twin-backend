import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { config, validateConfig } from './config.js';
import { db } from './db.js';
import { createEmailAccount, loginWithPassword, loginWithGoogle, requireAuth } from './auth.js';
import { generateTwinReply } from './ai.js';

validateConfig();
const app = express();
app.use(helmet());
app.use(cors({ origin: config.frontendOrigin === '*' ? true : config.frontendOrigin.split(',').map(s => s.trim()) }));
app.use(express.json({ limit: '1mb' }));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'my-twin-api' }));
app.post('/api/auth/register', (req, res, next) => {
  try { res.status(201).json(createEmailAccount(req.body || {})); } catch (e) { next(e); }
});
app.post('/api/auth/login', (req, res, next) => {
  try { res.json(loginWithPassword(req.body || {})); } catch (e) { next(e); }
});
app.post('/api/auth/google', async (req, res, next) => {
  try { res.json(await loginWithGoogle(req.body?.idToken)); } catch (e) { next(e); }
});
app.get('/api/me', requireAuth, (req, res) => res.json({ user: req.user }));

app.get('/api/profile', requireAuth, (req, res) => {
  const profile = db.prepare('SELECT display_name,bio,tone,interests,updated_at FROM profiles WHERE user_id=?').get(req.user.id);
  res.json({ profile });
});
app.put('/api/profile', requireAuth, (req, res, next) => {
  try {
    const allowed = ['display_name','bio','tone','interests'];
    const values = Object.fromEntries(allowed.map(k => [k, String(req.body?.[k] ?? '').slice(0, 3000)]));
    db.prepare(`INSERT INTO profiles(user_id,display_name,bio,tone,interests,updated_at)
      VALUES(@user_id,@display_name,@bio,@tone,@interests,CURRENT_TIMESTAMP)
      ON CONFLICT(user_id) DO UPDATE SET display_name=excluded.display_name,bio=excluded.bio,
      tone=excluded.tone,interests=excluded.interests,updated_at=CURRENT_TIMESTAMP`)
      .run({ user_id: req.user.id, ...values });
    res.json({ profile: db.prepare('SELECT display_name,bio,tone,interests,updated_at FROM profiles WHERE user_id=?').get(req.user.id) });
  } catch (e) { next(e); }
});
app.get('/api/chat/history', requireAuth, (req, res) => {
  const messages = db.prepare('SELECT id,role,content,created_at FROM messages WHERE user_id=? ORDER BY id DESC LIMIT 50').all(req.user.id).reverse();
  res.json({ messages });
});
app.post('/api/chat', requireAuth, async (req, res, next) => {
  try {
    const message = String(req.body?.message || '').trim();
    if (!message || message.length > 4000) return res.status(400).json({ error: 'Tin nhắn cần từ 1 đến 4000 ký tự.' });
    const profile = db.prepare('SELECT display_name,bio,tone,interests FROM profiles WHERE user_id=?').get(req.user.id) || {};
    const history = db.prepare('SELECT role,content FROM messages WHERE user_id=? ORDER BY id DESC LIMIT 12').all(req.user.id).reverse();
    const reply = await generateTwinReply({ profile, history, message });
    const insert = db.prepare('INSERT INTO messages(user_id,role,content) VALUES(?,?,?)');
    const save = db.transaction(() => {
      insert.run(req.user.id, 'user', message);
      insert.run(req.user.id, 'assistant', reply);
    });
    save();
    res.json({ reply });
  } catch (e) { next(e); }
});
app.delete('/api/account', requireAuth, (req, res) => {
  db.prepare('DELETE FROM users WHERE id=?').run(req.user.id);
  res.json({ ok: true });
});

app.use((err, _req, res, _next) => {
  const status = Number(err.status) || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 ? 'Máy chủ gặp lỗi.' : err.message });
});
app.listen(config.port, () => console.log(`MY TWIN API listening on port ${config.port}`));
