import test from 'node:test';
import assert from 'node:assert/strict';
import { createEmailAccount, loginWithPassword } from '../src/auth.js';
import { db } from '../src/db.js';
import { config } from '../src/config.js';

config.jwtSecret = 'test-secret-that-is-long-enough-for-unit-tests-123456';
test('register creates an account and password login returns a token', () => {
  const email = `test-${Date.now()}@example.com`;
  const created = createEmailAccount({ email, password: 'a-very-long-password' });
  assert.ok(created.token);
  assert.equal(created.user.email, email);
  const loggedIn = loginWithPassword({ email, password: 'a-very-long-password' });
  assert.equal(loggedIn.user.id, created.user.id);
  assert.throws(() => loginWithPassword({ email, password: 'wrong-password' }), /Email hoặc mật khẩu/);
  db.prepare('DELETE FROM users WHERE id=?').run(created.user.id);
});
