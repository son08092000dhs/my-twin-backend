# MY TWIN — Backend API starter

Đây là **backend thật dạng mã nguồn**, chưa phải website đã được xuất bản. API gồm đăng ký/đăng nhập email, xác minh Google ID token (khi cấu hình OAuth), hồ sơ riêng theo tài khoản, lịch sử chat lưu SQLite và endpoint gọi OpenAI.

## Cần chuẩn bị
- Máy tính để chạy/deploy Node.js 20+ (không thể triển khai máy chủ chỉ bằng cách mở file trên Android).
- Tài khoản hosting hỗ trợ Node.js.
- OpenAI API key để bật AI thật.
- Google OAuth Web Client ID để bật đăng nhập Google.

## Chạy thử trên máy tính
1. Cài Node.js 20 trở lên.
2. Giải nén thư mục.
3. Chạy `npm install`.
4. Sao chép `.env.example` thành `.env`.
5. Đặt `JWT_SECRET` thành chuỗi ngẫu nhiên dài ít nhất 32 ký tự.
6. Đặt `OPENAI_API_KEY` trong `.env` để bật AI; không gửi key cho người khác và không đưa vào frontend.
7. Chạy `npm test`, sau đó `npm start`.
8. Mở `http://localhost:3000/health` để kiểm tra.

## API
- `POST /api/auth/register` — `{ "email": "...", "password": "ít nhất 10 ký tự" }`
- `POST /api/auth/login` — `{ "email": "...", "password": "..." }`
- `POST /api/auth/google` — `{ "idToken": "Google ID token" }`
- `GET /api/profile` — Bearer token
- `PUT /api/profile` — Bearer token, JSON: `display_name`, `bio`, `tone`, `interests`
- `GET /api/chat/history` — Bearer token
- `POST /api/chat` — Bearer token, JSON `{ "message": "..." }`
- `DELETE /api/account` — Bearer token, xóa tài khoản và dữ liệu liên quan

## Quan trọng trước khi đưa lên Internet
- Dùng HTTPS và hosting có persistent disk cho SQLite; với nhiều người dùng/scale lớn hãy chuyển sang PostgreSQL.
- Cấu hình `FRONTEND_ORIGIN` đúng domain frontend.
- Cấu hình Google OAuth authorized origins/redirects theo nhà cung cấp đăng nhập.
- Thêm rate limiting, email verification, reset password, backup và giám sát trước khi mở đăng ký công khai.
- Chat chỉ lưu nội dung sau khi OpenAI trả lời thành công. API key chỉ ở biến môi trường máy chủ.
- Chưa có frontend kết nối các API này; file HTML demo trước đó không tự động dùng backend này.
